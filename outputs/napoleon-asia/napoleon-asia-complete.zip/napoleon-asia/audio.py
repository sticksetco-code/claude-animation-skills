import numpy as np, soundfile as sf, json
from scipy import signal
SR = 44100
import json as _j, os as _os
WARP = None
def toNew(x):
    if not WARP: return x
    A = WARP['anchors']
    if x <= A[0][0]: return x - A[0][0] + A[0][1]
    for i in range(len(A) - 1):
        if x <= A[i + 1][0]: k = (x - A[i][0]) / (A[i + 1][0] - A[i][0]); return A[i][1] + k * (A[i + 1][1] - A[i][1])
    return x - A[-1][0] + A[-1][1]
DUR = 40.0
N = int(DUR * SR)
rng = np.random.default_rng(3)
def T(n): return np.arange(n) / SR
def env(n, a=.005, d=.2, curve=4):
    t = T(n); e = np.minimum(1, t / max(a, 1e-4)) * np.exp(-np.maximum(0, t - a) * curve / max(d, 1e-4)); return e
def place(buf, x, at, g=1.0):
    i = int(toNew(at) * SR); j = min(len(buf), i + len(x))
    if i < 0 or i >= len(buf): return
    buf[i:j] += x[:j - i] * g
def bp(x, lo, hi, order=2):
    b, a = signal.butter(order, [lo / (SR / 2), min(hi / (SR / 2), .99)], 'band'); return signal.lfilter(b, a, x)
def lp(x, f, order=2):
    b, a = signal.butter(order, f / (SR / 2), 'low'); return signal.lfilter(b, a, x)
def hp(x, f, order=2):
    b, a = signal.butter(order, f / (SR / 2), 'high'); return signal.lfilter(b, a, x)

# ---------------- SFX ----------------
def whoosh(dur=.35, up=True):
    n = int(dur * SR); x = rng.standard_normal(n); t = T(n)
    lo, hi = bp(x, 250, 1200), bp(x, 1500, 6000); k = np.linspace(0, 1, n) if up else np.linspace(1, 0, n)
    e = np.sin(np.pi * np.clip(t / dur, 0, 1)) ** 1.5
    return (lo * (1 - k) + hi * k) * e * 1.6
def thud(f0=70, dur=.35, g=1):
    n = int(dur * SR); t = T(n); f = f0 * (1 + 1.5 * np.exp(-t * 30))
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 12)
    x += lp(rng.standard_normal(n), 900) * np.exp(-t * 40) * .6
    return x * g
def clang(f0=520, dur=1.0):
    n = int(dur * SR); t = T(n); x = np.zeros(n)
    for k, (r, a, d) in enumerate([(1, 1, 5), (2.76, .6, 7), (5.4, .4, 10), (8.9, .25, 14), (1.5, .5, 6)]):
        x += a * np.sin(2 * np.pi * f0 * r * t + k) * np.exp(-t * d)
    x += hp(rng.standard_normal(n), 2000) * np.exp(-t * 60) * .8
    return x * .5 + thud(90, dur, .7)[:n]
def pluck(f, dur=.5, bright=.5):
    n = int(dur * SR); p = int(SR / f); buf = rng.uniform(-1, 1, p); out = np.zeros(n)
    for i in range(n):
        out[i] = buf[i % p]; buf[i % p] = bright * buf[i % p] + (1 - bright) * .5 * (buf[i % p] + buf[(i + 1) % p]) * .996 if False else .5 * (buf[i % p] + buf[(i + 1) % p]) * .995
    return out
def chime(f=1760, dur=.8):
    n = int(dur * SR); t = T(n)
    return (np.sin(2 * np.pi * f * t) + .5 * np.sin(2 * np.pi * f * 2.01 * t) + .3 * np.sin(2 * np.pi * f * 3 * t)) * np.exp(-t * 6) * np.minimum(1, t / .003) * .5
def sparkle_sfx():
    out = np.zeros(int(.7 * SR))
    for i, f in enumerate([2093, 2637, 3136, 4186]): place(out, chime(f, .5) * .5, i * .05)
    return out
def tick(): n = int(.04 * SR); t = T(n); return hp(rng.standard_normal(n), 3000) * np.exp(-t * 200) * .8 + np.sin(2 * np.pi * 2400 * t) * np.exp(-t * 150) * .4
def pop(f=600):
    n = int(.12 * SR); t = T(n); fr = f * (1 + 2 * t * 10); return np.sin(2 * np.pi * np.cumsum(fr) / SR) * np.exp(-t * 40)
def boing(f=220, dur=.5):
    n = int(dur * SR); t = T(n); fr = f * (1 + .35 * np.sin(2 * np.pi * 9 * t) * np.exp(-t * 3)) * (1 + t)
    return np.sin(2 * np.pi * np.cumsum(fr) / SR) * np.exp(-t * 5) * .6
def tweet():
    out = np.zeros(int(1.2 * SR))
    for i in range(4):
        n = int(.1 * SR); t = T(n); fr = 3200 + 900 * np.sin(2 * np.pi * 30 * t)
        place(out, np.sin(2 * np.pi * np.cumsum(fr) / SR) * np.sin(np.pi * t / .1) * .25, i * .25)
    return out
def scribble(dur=.18):
    n = int(dur * SR); t = T(n); return bp(rng.standard_normal(n), 1500, 6000) * (0.5 + .5 * np.sin(2 * np.pi * 30 * t)) * np.sin(np.pi * t / dur) * .5
def riser(dur=2.8):
    n = int(dur * SR); t = T(n); f = 200 * (2 ** (t / dur * 2.5))
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * .3 + bp(rng.standard_normal(n), 800, 5000) * .3 * (t / dur)
    return x * (t / dur) ** 2
def waves(dur):
    n = int(dur * SR); t = T(n); x = lp(rng.standard_normal(n), 700, 2)
    return x * (0.5 + .5 * np.sin(2 * np.pi * t / 4.5) ** 2) * .5
def heartbeat():
    out = np.zeros(int(.8 * SR)); place(out, thud(55, .3, .8), 0); place(out, thud(50, .3, .6), .22); return out

# Original score and scene cues for Napoleon's fictional expedition.
sfx=np.zeros(N);music=np.zeros(N)
for at in [4.85,7.1,9.85,15.85,21.85,28.85,34.85,38.85]:place(sfx,whoosh(.35),at-.15,.25)
place(sfx,waves(10),0,.15);place(sfx,waves(6),10,.08)
for at in [.5,2.1,11.7,12.4,13.1,18.7,20.2,36.65]:place(sfx,pop(480+int(at*30)),at,.22)
for at in [.2,23.1,36.65]:place(sfx,thud(70,.4),at,.35)
for i in range(16):place(sfx,tick(),5.05+i*.052,.17)
place(sfx,whoosh(.55),8,.15);place(sfx,sparkle_sfx(),12,.24)
place(sfx,chime(900),17,.15);place(sfx,boing(260),18.8,.24)
for at in np.arange(23.5,28.8,.34):place(sfx,thud(100,.10),at,.18)
place(sfx,boing(180,.7),24.4,.24);place(sfx,sparkle_sfx(),30,.18)
# Record-scratch gesture, then running feet and a comic sting.
t=T(int(.5*SR));scratch=bp(rng.standard_normal(len(t)),400,3000)*(0.4+.6*np.sin(2*np.pi*18*t))*np.sin(np.pi*t/.5)
place(sfx,scratch,36.7,.28)
for at in np.arange(37.8,38.9,.11):place(sfx,thud(140,.07),at,.19)
place(sfx,boing(160,.6),39,.25)

def midi(n):return 440*2**((n-69)/12)
def pizz(m,d=.55):
 t=T(int(d*SR));f=midi(m);return (np.sin(2*np.pi*f*t)+.32*np.sin(2*np.pi*f*2*t)+.13*np.sin(2*np.pi*f*3*t))*np.minimum(1,t/.006)*np.exp(-t*9)
beat=60/132
patterns=[[62,69,65,74,69,65,72,69],[62,65,69,77,74,69,65,69],[65,69,72,77,76,72,69,65],[57,64,67,72,71,67,64,61]]
for i,at in enumerate(np.arange(0,40,beat/2)):
 section=int(at//5);pat=patterns[section%4];note=pat[i%8]
 gain=.075 if at<22 or at>=29 else .045
 place(music,pizz(note),at,gain)
 if i%4==0:place(music,pizz(note-24,1.0),at,.12)
 if i%2==0:place(music,thud(65,.15),at,.055 if at<22 else .11)
 if i%4==2:place(music,bp(rng.standard_normal(int(.1*SR)),1400,5000)*np.exp(-T(int(.1*SR))*45),at,.055)
for at in [0,5,10,16,22,29,35]:
 t=T(int(2*SR));chord=sum(np.sin(2*np.pi*midi(n)*t) for n in [50,57,65]);place(music,chord*np.sin(np.pi*t/2)*.013,at)
# A falling bassoon-like motif gives the final reaction a musical payoff.
for i,n in enumerate([62,61,57,50]):place(music,pizz(n,.8),38.9+i*.20,.17)
voice,sr=sf.read('audio/vo.wav');voice=signal.resample_poly(voice,147,80) if sr==24000 else signal.resample(voice,N);voice=np.pad(voice,(0,max(0,N-len(voice))))[:N]
from scipy.ndimage import maximum_filter1d,gaussian_filter1d
activity=maximum_filter1d(np.abs(voice),size=4411);duck=1-.68*np.clip(gaussian_filter1d(activity,900)*10,0,1)
music*=duck
fade=np.minimum(1,T(N)/.3)*np.minimum(1,(40-T(N))/.45);music*=fade;sfx*=fade
sf.write('audio/music.wav',music,SR);sf.write('audio/sfx.wav',sfx,SR)
mono=voice*.95+music+sfx*.7
# Gentle room depth on accompaniment only; voice stays centered.
delay=np.zeros(N);delay[1102:]=(music+sfx*.3)[:-1102]*.13
mix=np.column_stack([mono+delay,mono-delay*.4]);mix*=min(1,.94/max(.01,np.max(np.abs(mix))))
sf.write('audio/mix.wav',mix,SR)
print('Mixed 40 seconds of voice, original score and synchronized SFX; peak',np.max(np.abs(mix)))
