"""Fit generated sentence takes into storyboard slots; remap recognized word times."""
import json, subprocess
from pathlib import Path
import numpy as np, soundfile as sf
p=Path('.')
starts=[.40,5.10,7.45,10.60,16.50,22.50,29.50,35.20,38.20]
durations=[3.40,2.20,2.30,4.80,4.20,4.90,4.20,2.65,1.20]
meta=json.loads(Path('audio/lines.json').read_text())
raw=Path('audio/words_raw.json')
if not raw.exists(): raw.write_text(Path('audio/words_new.json').read_text())
words=json.loads(raw.read_text());sr=24000;out=np.zeros(sr*40,dtype=np.float32)
for i,(at,dur) in enumerate(zip(starts,durations)):
 a,rate=sf.read(f'audio/line_{i:02d}.wav');factor=(len(a)/rate)/dur
 subprocess.run(['ffmpeg','-v','error','-y','-i',f'audio/line_{i:02d}.wav','-af',f'atempo={factor:.9f},apad,atrim=duration={dur}','-ar',str(sr),f'audio/timed_{i:02d}.wav'],check=True)
 a,rate=sf.read(f'audio/timed_{i:02d}.wav');out[round(at*sr):round(at*sr)+len(a)]=a
 for w in words:
  if w['line']==i:
   w['s']=round(at+max(0,w['s']-meta[i]['start'])/factor,3)
   w['e']=round(min(at+dur,at+max(0,w['e']-meta[i]['start'])/factor),3)
   w['s']=min(w['s'],at+dur-.04);w['e']=max(w['s']+.02,w['e'])
sf.write('audio/vo.wav',out,sr)
Path('audio/words_new.json').write_text(json.dumps(words,indent=2))
Path('web/words.js').write_text('const WORDS='+json.dumps(words)+';')
Path('web/warp.js').write_text('window.WARP=null;')
Path('audio/scene_timing.json').write_text(json.dumps([{'text':m['text'],'start':s,'duration':d} for m,s,d in zip(meta,starts,durations)],indent=2))
# Human-readable subtitle track, using the same two-word groups as the compositor.
chunks=[]
for w in words:
 if not chunks or len(chunks[-1]['words'])>=2 or len(' '.join(chunks[-1]['words'])+' '+w['w'])>13 or chunks[-1]['line']!=w['line'] or chunks[-1]['words'][-1][-1] in '.,?!':
  chunks.append({'words':[w['w']],'s':w['s'],'e':w['e'],'line':w['line']})
 else:chunks[-1]['words'].append(w['w']);chunks[-1]['e']=w['e']
def ts(t):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
Path('narration.srt').write_text('\n\n'.join(f'{i+1}\n{ts(c["s"])} --> {ts(c["e"])}\n'+ ' '.join(c['words']) for i,c in enumerate(chunks))+'\n')
print('Timed voice: exactly 40 seconds; words:',len(words))
