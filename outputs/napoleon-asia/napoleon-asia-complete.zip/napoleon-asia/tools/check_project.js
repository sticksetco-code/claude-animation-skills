const {chromium}=require('playwright');
const fs=require('fs'),http=require('http'),path=require('path');
(async()=>{
 const root=process.cwd(),errors=[];
 const server=http.createServer((req,res)=>{if(req.url==='/favicon.ico'){res.writeHead(204);res.end();return;}let f=path.join(root,req.url.split('?')[0]);fs.readFile(f,(e,d)=>{if(e){res.writeHead(404);res.end();return;}res.setHeader('Content-Type',f.endsWith('.js')?'text/javascript':f.endsWith('.html')?'text/html':'application/octet-stream');res.end(d)});});
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const b=await chromium.launch({executablePath:process.env.CHROME||'/usr/bin/chromium'}),p=await b.newPage();
 p.on('pageerror',e=>errors.push(e.message));p.on('response',r=>{if(r.status()>=400)errors.push(r.status()+' '+r.url())});
 await p.goto('http://127.0.0.1:'+server.address().port+'/web/index.html');await p.evaluate(()=>document.fonts.ready);
 const result=await p.evaluate(()=>{
  const cc=document.createElement('canvas');cc.width=54;cc.height=96;const cx=cc.getContext('2d',{willReadFrequently:true});const hashes=[];
  for(let f=0;f<1200;f+=15){renderFrame(f);cx.drawImage(canvas,0,0,54,96);let d=cx.getImageData(0,0,54,96).data,h=2166136261;for(let v of d)h=Math.imul(h^v,16777619);hashes.push(h>>>0)}
  out.font='700 70px Poppins';let maxWidth=Math.max(...CHUNKS.map(c=>out.measureText(capText(c.text)).width));
  return {duration:DUR,totalFrames:TOTAL_FRAMES,scenes:SHOT_SPANS,captionGroups:CHUNKS.length,maxCaptionWidth:maxWidth,sampleCount:hashes.length,uniqueSamples:new Set(hashes).size,hashes};
 });
 await b.close();server.close();result.errors=errors;
 if(errors.length||result.duration!==40||result.totalFrames!==1200||result.scenes.length!==7||result.maxCaptionWidth>800||result.uniqueSamples<76)throw Error(JSON.stringify(result));
 fs.writeFileSync('project-check.json',JSON.stringify(result,null,2));console.log(JSON.stringify({...result,hashes:undefined}));
})().catch(e=>{console.error(e);process.exit(1)});
