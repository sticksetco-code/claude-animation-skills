#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
KIT="${ANIMATION_KIT:-/workspace/claude-animation-skills/kit}"
export NODE_PATH="$KIT/node_modules"
export CHROME="${CHROME:-/usr/bin/chromium}"
mkdir -p seg
node tools/render.js segments 0,3,6 > seg/render-0.log 2>&1 & p0=$!
node tools/render.js segments 1,4 > seg/render-1.log 2>&1 & p1=$!
node tools/render.js segments 2,5 > seg/render-2.log 2>&1 & p2=$!
wait "$p0"; wait "$p1"; wait "$p2"
python3 - <<'PY'
from pathlib import Path
files=sorted(Path('seg').glob('shot_??.mp4'))
assert len(files)==7, 'Expected seven rendered scenes'
Path('seg/list.txt').write_text(''.join("file '"+p.name+"'\n" for p in files))
PY
ffmpeg -v error -y -f concat -safe 0 -i seg/list.txt -c copy silent.mp4
ffmpeg -v error -y -i silent.mp4 -i audio/mix.wav -map 0:v -map 1:a -c:v libx264 -threads 2 -preset medium -crf 22 -pix_fmt yuv420p -af 'alimiter=limit=0.9:attack=2:release=60,loudnorm=I=-14:TP=-1.5:LRA=9' -c:a aac -b:a 192k -ar 48000 -t 40 -movflags +faststart napoleon-asia.mp4
ffprobe -v error -count_frames -show_entries stream=codec_name,width,height,r_frame_rate,nb_read_frames -show_entries format=duration -of json napoleon-asia.mp4 > verification.json
